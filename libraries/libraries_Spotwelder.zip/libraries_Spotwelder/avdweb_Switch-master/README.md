### The advantages of the Switch library are:
- External pull-up resistors are not required.
- Supports also long press and double clicks.
- Performs not just de-bouncing, but also de-glitching against EMC pulses.

For more information see: http://www.avdweb.nl/arduino/hardware-interfacing/simple-switch-debouncer.html
